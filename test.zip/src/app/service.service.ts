import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {


  EmployeeArray: any= [];

  constructor() { }

  setEmploye(val) {
    this.EmployeeArray.push(val);
  }

  getEmp() {
    return this.EmployeeArray;
  }
}
