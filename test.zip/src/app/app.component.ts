import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ServiceService } from './service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  
  employeeForm: FormGroup; 
  employeeArray: any = [];

  constructor(private formBuilder: FormBuilder, private services: ServiceService){
    this.employeeForm = this.formBuilder.group({
      firstName: [null],
      lastName: [null],
      City: [null],
      birthDate: [null],
      mobileNo: [null],
      Salary: [null],
      adharCard: [null],
      panCard: [null],
      prfileImg: [null],
      documents: [null]
    })
  };


  ngOnInit(){
    this.getEmp();
  }

  saveEmpmloyee(value) {
    console.log('value', value);
    // this.employeeArray.push(value);
    this.services.setEmploye(value)
  }

  getEmp() {
    this.employeeArray = this.services.getEmp();
  }

  changePage() {}


}
